module.exports=[72123,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/script.js <module evaluation>"))},44536,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/script.js"))},11153,a=>{"use strict";a.i(72123);var b=a.i(44536);a.n(b)},71618,(a,b,c)=>{b.exports=a.r(11153)},27572,a=>{"use strict";var b=a.i(7997),c=a.i(71618);function d({children:a}){return(0,b.jsx)("html",{lang:"en",children:(0,b.jsxs)("body",{className:"antialiased",children:[a,(0,b.jsx)(c.default,{id:"remove-nextjs-portal",strategy:"afterInteractive",dangerouslySetInnerHTML:{__html:`
              (function() {
                function removeNextJSPortal() {
                  const portal = document.querySelector('nextjs-portal');
                  if (portal) {
                    portal.remove();
                  }
                }
                if (document.readyState === 'loading') {
                  document.addEventListener('DOMContentLoaded', removeNextJSPortal);
                } else {
                  removeNextJSPortal();
                }
                const observer = new MutationObserver(removeNextJSPortal);
                observer.observe(document.body, { childList: true, subtree: true });
              })();
            `}})]})})}a.s(["default",()=>d,"metadata",0,{title:"World Nuclear Exhibition 2027",description:"The world's leading civil nuclear exhibition. WNE connects you with the most comprehensive network of worldwide top-tier suppliers and service providers across the entire nuclear sector."}])}];

//# sourceMappingURL=_c1f13f8e._.js.map